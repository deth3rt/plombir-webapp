const tg = window.Telegram.WebApp;
tg.expand();

// База данных луков и элементов (никаких сокращений, полная кастомизация)
const database = {
    boys: {
        title: "ГОРОДСКОЙ ПАРЕНЬ НА СЕЛЕ",
        items: [
            { icon: "👕", name: "ТЕНЬЯШКА", desc: "классика деревни" },
            { icon: "🩳", name: "СПОРТИВНЫЕ ШОРТЫ", desc: "удобно и по-нашему" },
            { icon: "👟", name: "БЕЛЫЕ НОСКИ", desc: "с уважением к стилю" },
            { icon: "🩴", name: "СЛАНЦЫ", desc: "деревенский вайб" },
            { icon: "🧢", name: "БАНДИТСКИЙ КЕРАМИК", desc: "для своих пацанов" },
            { icon: "⛓", name: "ЦЕПЬ", desc: "на стиле" }
        ],
        // Ссылка на фоновый сгенерированный арт (подставь свои картинки персонажей из репозитория)
        baseArt: "boys_base.png" 
    },
    girls: {
        title: "ДЕРЕВЕНСКИЙ ГЛАМУР",
        items: [
            { icon: "👗", name: "ВИНТАЖНЫЙ САРАФАН", desc: "а-ля рюсс" },
            { icon: "👒", name: "СОЛОМЕННАЯ ШЛЯПА", desc: "от солнца и сглаза" },
            { icon: "🩴", name: "СЛАНЦЫ С ЦВЕТОЧКАМИ", desc: "люкс" },
            { icon: "🕶", name: "ОЧКИ С РЫЦАРСКИМ ОТБЛЕСКОМ", desc: "стиль 90-х" }
        ],
        baseArt: "girls_base.png"
    }
};

const loadingPhrases = [
    "Стряхиваем пыль с олимпийки...",
    "Проверяем карманы на наличие семечек...",
    "Натираем сланцы до зеркального блеска...",
    "Интегрируем славянский вайб в реальность...",
    "Финальные штрихи подиумного лука..."
];

let selectedGender = '';
let currentItems = [];
let userAvatarDataUrl = '';
let currentLookId = '';

// Шаг 1: Выбор пола
function selectGender(gender) {
    selectedGender = gender;
    currentItems = database[gender].items;

    document.getElementById('screen-gender').classList.add('hidden');
    document.getElementById('screen-preview').classList.remove('hidden');

    document.getElementById('preview-category-title').textContent = database[gender].title;

    const container = document.getElementById('itemsListContainer');
    container.innerHTML = currentItems.map(item => `
        <div class="item-row">
            <span class="item-icon">${item.icon}</span>
            <div class="item-info">
                <span class="item-name">${item.name}</span>
                <span class="item-desc">${item.desc}</span>
            </div>
        </div>
    `).join('');
}

// Шаг 2: Переход к загрузке селфи
function goToPhotoUpload() {
    document.getElementById('screen-preview').classList.add('hidden');
    document.getElementById('screen-upload').classList.remove('hidden');
}

// Шаг 3: Обработка загруженного фото
function handleImageUpload(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            userAvatarDataUrl = e.target.result;
            
            // Показываем превью аватара
            document.getElementById('avatarPreviewImg').src = userAvatarDataUrl;
            document.getElementById('dropZone').classList.add('hidden');
            document.getElementById('avatarPreviewContainer').classList.remove('hidden');
            document.getElementById('generateBtn').classList.remove('hidden');
        };
        reader.readAsDataURL(file);
    }
}

// Сброс или смена фото при клике на аватар
document.getElementById('avatarPreviewContainer').addEventListener('click', () => {
    document.getElementById('selfieInput').value = '';
    document.getElementById('dropZone').classList.remove('hidden');
    document.getElementById('avatarPreviewContainer').classList.add('hidden');
    document.getElementById('generateBtn').classList.add('hidden');
});

// Шаг 4: Запуск процесса генерации постера
function startGenerationProcess() {
    document.getElementById('screen-upload').classList.add('hidden');
    document.getElementById('screen-loading').classList.remove('hidden');

    currentLookId = `PLMBR-${Math.floor(1000 + Math.random() * 9000)}`;

    let step = 0;
    const statusEl = document.getElementById('loading-status-text');
    
    const interval = setInterval(() => {
        statusEl.textContent = loadingPhrases[step % loadingPhrases.length];
        step++;
    }, 800);

    // Имитация быстрой сборки без лагов
    setTimeout(() => {
        clearInterval(interval);
        document.getElementById('screen-loading').classList.add('hidden');
        document.getElementById('screen-result').classList.remove('hidden');
        renderCanvasPoster();
    }, 2800);
}

// Шаг 5: Отрисовка фирменного постера на Canvas (соединяет арт, селфи, рамки и текст)
async function renderCanvasPoster() {
    const canvas = document.getElementById('posterCanvas');
    const ctx = canvas.getContext('2d');

    // Базовый размер холста под вертикальный постер
    canvas.width = 1000;
    canvas.height = 1400;

    // 1. Заливка фона
    ctx.fillStyle = "#121215";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // 2. Рисуем заглушку / базовый персонаж (в реальном проекте подгружается картинка из папки)
    // Отрисуем стилизованную плашку-каркас под персонажа
    ctx.fillStyle = "#1b1b22";
    ctx.fillRect(60, 200, 880, 820);

    // Если пользователь загрузил фото, вставляем его в левый верхний угол (блок "Твое фото")
    if (userAvatarDataUrl) {
        const userImg = new Image();
        userImg.src = userAvatarDataUrl;
        await new Promise((resolve) => userImg.onload = resolve);
        
        // Рисуем круглое селфи в рамке на холсте
        ctx.save();
        ctx.beginPath();
        ctx.arc(160, 280, 70, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(userImg, 90, 210, 140, 140);
        ctx.restore();

        // Обводка аватарки
        ctx.strokeStyle = "#c8e66e";
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(160, 280, 70, 0, Math.PI * 2, true);
        ctx.stroke();
    }

    // 3. Текст шапки и ID лука
    ctx.fillStyle = "#c8e66e";
    ctx.font = "900 42px Montserrat, sans-serif";
    ctx.fillText("ПLОМБИР", 60, 100);

    ctx.fillStyle = "#8e8e99";
    ctx.font = "700 20px Montserrat, sans-serif";
    ctx.fillText("ИЗ ГОРОДА В ДЕРЕВНЮ", 60, 135);

    // Уникальный ID лука справа вверху
    ctx.fillStyle = "#f5f5f7";
    ctx.font = "700 32px 'Space Mono', monospace";
    ctx.textAlign = "right";
    ctx.fillText(currentLookId, canvas.width - 60, 115);
    ctx.textAlign = "left";

    // 4. Блок списка одежды на холсте
    ctx.fillStyle = "#ffffff";
    ctx.font = "900 24px Montserrat, sans-serif";
    ctx.fillText("ТВОЙ ЛУК:", 60, 1080);

    let startY = 1120;
    currentItems.forEach(item => {
        ctx.fillStyle = "#8e8e99";
        ctx.font = "700 18px 'Space Mono', monospace";
        ctx.fillText(`• ${item.name} (${item.desc})`, 60, startY);
        startY += 35;
    });

    // 5. Внешняя дизайнерская рамка
    ctx.strokeStyle = "#2e2e3a";
    ctx.lineWidth = 12;
    ctx.strokeRect(0, 0, canvas.width, canvas.height);
}

// Возврат к началу
function resetApp() {
    document.getElementById('screen-result').classList.add('hidden');
    document.getElementById('screen-gender').classList.remove('hidden');
    document.getElementById('selfieInput').value = '';
    document.getElementById('dropZone').classList.remove('hidden');
    document.getElementById('avatarPreviewContainer').classList.add('hidden');
    document.getElementById('generateBtn').classList.add('hidden');
    userAvatarDataUrl = '';
}

// Отправка готового постера обратно в Telegram-бот
function sendPosterToBot() {
    const canvas = document.getElementById('posterCanvas');
    canvas.toBlob(function(blob) {
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = function() {
            const base64data = reader.result;
            
            if (tg.initDataUnsafe && tg.initDataUnsafe.user) {
                // Передаем данные на бэкенд бота
                tg.sendData(JSON.stringify({
                    look_id: currentLookId,
                    image: base64data
                }));
            } else {
                alert(`Постер ${currentLookId} успешно сформирован! В Telegram он отправится в чат одной кнопкой.`);
            }
        };
    }, 'image/png', 0.95);
}