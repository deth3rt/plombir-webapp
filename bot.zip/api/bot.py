import os
import json
from http.server import BaseHTTPRequestHandler
import requests

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
WEBAPP_URL = os.getenv("WEBAPP_URL")

class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            update = json.loads(post_data.decode('utf-8'))

            if "message" in update:
                chat_id = update["message"]["chat"]["id"]
                user_name = update["message"]["from"].get("first_name", "Дружище")
                text = update["message"].get("text", "")

                if text.startswith("/start"):
                    self.send_welcome(chat_id, user_name)

            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(b'{"ok": true}')
        except Exception as e:
            self.send_response(500)
            self.end_headers()
            self.wfile.write(str(e).encode('utf-8'))

    def send_welcome(self, chat_id, user_name):
        url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
        
        keyboard = {
            "inline_keyboard": [
                [{"text": "🚜 СОЗДАТЬ СВОЙ ЛУК", "web_app": {"url": WEBAPP_URL}}]
            ]
        }
        
        payload = {
            "chat_id": chat_id,
            "text": (
                f"Здорово, **{user_name}**!\n\n"
                "Добро пожаловать в официальный бот вечеринки **ПLОМБИР: ИЗ ГОРОДА В ДЕРЕВНЮ**.\n\n"
                "Жми на кнопку ниже, выбирай стиль, загружай селфи и забирай свой эксклюзивный постер!"
            ),
            "parse_mode": "Markdown",
            "reply_markup": json.dumps(keyboard)
        }
        requests.post(url, json=payload)

    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        self.end_headers()
        self.wfile.write(b"Plmbr Bot Serverless is running!")